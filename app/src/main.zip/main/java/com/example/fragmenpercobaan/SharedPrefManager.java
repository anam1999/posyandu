package com.example.fragmenpercobaan;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {
    public static final String id = "ID";
    public static final String NAME = "name";
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public SharedPrefManager(Context context) {
        sharedPreferences = context.getSharedPreferences(id, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void saveSPString(String keySP, String value) {
        editor.putString(keySP, value);
        editor.commit();
    }

    public void saveSPBoolean(String keySP, Boolean value) {
        editor.putBoolean(keySP, value);
        editor.commit();
    }
    public String getname() {
        return sharedPreferences.getString(NAME, "");
    }
}
