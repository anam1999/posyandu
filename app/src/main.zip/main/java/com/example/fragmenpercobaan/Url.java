package com.example.fragmenpercobaan;

public class Url {
    public static String URL = "http://192.168.43.229/posdayandu/public/api";
}
