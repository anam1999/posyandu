package com.example.fragmenpercobaan;

import android.content.Context;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.error.AuthFailureError;
import com.android.volley.error.VolleyError;
import com.android.volley.request.JsonArrayRequest;
import com.example.fragmenpercobaan.Model.Anak;
import com.example.fragmenpercobaan.Model.Ibu;
import com.example.fragmenpercobaan.Model.Imunisasi;
import com.example.fragmenpercobaan.Model.Kontrol_Hamil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Anak>> listanak = new MutableLiveData<>();
    private MutableLiveData<ArrayList<Kontrol_Hamil>> listkontrolhamil = new MutableLiveData<>();
    private MutableLiveData<ArrayList<Ibu>> listibu = new MutableLiveData<>();
    private MutableLiveData<ArrayList<Imunisasi>> listimunisasi = new MutableLiveData<>();

    public MainViewModel() {
    }
    public void setAnak (RequestQueue queue, final Context context) {
        final ArrayList<Anak> listItemAnak = new ArrayList<>();



        String url = Url.URL+"/dataanak/34";
        JsonArrayRequest arrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject data = response.getJSONObject(i);
                        Anak anak = new Anak();
                        anak.setId(data.getString("id"));
                        anak.setName(data.getString("nama"));
                        anak.setUsia(data.getString("usia"));
                        anak.setJadwal(data.getString("jadwal"));
                        anak.setBb(data.getString("bb"));

                        listItemAnak.add(anak);
                    }
                    listanak.postValue(listItemAnak);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> data = new HashMap<>();
                return data;
            }
        };
        queue.getCache().clear();
        queue.add(arrayRequest);
    }
    public LiveData<ArrayList<Anak>> getAnak() {
        return listanak;
    }

    public void setIbu (RequestQueue queue, final Context context) {
        final ArrayList<Ibu> listItemIbu = new ArrayList<>();



        String url = Url.URL+"/show_ibu/34";
        JsonArrayRequest arrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject data = response.getJSONObject(i);
                        Ibu ibu = new Ibu();
                        ibu.setId(data.getString("id"));
                        ibu.setName(data.getString("name"));
                        ibu.setStatus(data.getString("status"));
                        ibu.setJumlah_anak(data.getString("jumlah_anak"));
                        ibu.setNik(data.getString("nik"));

                        listItemIbu.add(ibu);
                    }
                    listibu.postValue(listItemIbu);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> data = new HashMap<>();
                return data;
            }
        };
        queue.getCache().clear();
        queue.add(arrayRequest);
    }
    public LiveData<ArrayList<Ibu>> getIbu() {
        return listibu;
    }

    //kontrolhamil
    public void setKontrolhamil (RequestQueue queue, final Context context) {
        final ArrayList<Kontrol_Hamil> listItemkontrolHamil = new ArrayList<>();

        String url = Url.URL+"/kontrolkehamilan/34";
        JsonArrayRequest arrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject data = response.getJSONObject(i);
                        Kontrol_Hamil kontrolHamil = new Kontrol_Hamil();
                        kontrolHamil.setId(data.getString("id"));
                        kontrolHamil.setName(data.getString("nama"));
                        kontrolHamil.setKondisi(data.getString("kondisi_kehamilan"));
                        kontrolHamil.setJadwal(data.getString("jadwal"));

                        listItemkontrolHamil.add(kontrolHamil);
                    }
                    listkontrolhamil.postValue(listItemkontrolHamil);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> data = new HashMap<>();
                return data;
            }
        };
        queue.getCache().clear();
        queue.add(arrayRequest);
    }
    public LiveData<ArrayList<Kontrol_Hamil>> getKontrolHamil() {
        return listkontrolhamil;
    }



    public void setImunisasi (RequestQueue queue, final Context context) {
        final ArrayList<Imunisasi> listItemImunisasi = new ArrayList<>();



        String url = Url.URL+"/imunisasi/34";
        JsonArrayRequest arrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject data = response.getJSONObject(i);
                        Imunisasi imunisasi = new Imunisasi();
                        imunisasi.setId(data.getString("id"));
                        imunisasi.setName(data.getString("nama"));
                        imunisasi.setNama_vaksin(data.getString("nama_vaksin"));
                        imunisasi.setJadwal(data.getString("jadwal"));

                        listItemImunisasi.add(imunisasi);
                    }
                    listimunisasi.postValue(listItemImunisasi);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> data = new HashMap<>();
                return data;
            }
        };
        queue.getCache().clear();
        queue.add(arrayRequest);
    }
    public LiveData<ArrayList<Imunisasi>> getImunisasi() {
        return listimunisasi;
    }


}