package com.example.fragmenpercobaan.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fragmenpercobaan.Model.Anak;
import com.example.fragmenpercobaan.R;

import java.util.ArrayList;

public class RecyclerViewAnak extends RecyclerView.Adapter<RecyclerViewAnak.RekapitulasiViewHolder> {

    ArrayList<Anak> list = new ArrayList<>();

    public void sendData(ArrayList<Anak> anak) {
        list.clear();
        list.addAll(anak);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RekapitulasiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_anak, parent, false);
        return new RekapitulasiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RekapitulasiViewHolder holder, int position) {
        Anak anak = list.get(position);
        holder.name.setText(anak.getName());
        holder.usia.setText(anak.getUsia());
        holder.jadwal.setText(anak.getJadwal());
        holder.bb.setText(anak.getBb());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class RekapitulasiViewHolder extends RecyclerView.ViewHolder {
        TextView name, usia, jadwal,bb;

        public RekapitulasiViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name_anak);
            usia = itemView.findViewById(R.id.usia_anak);
            jadwal = itemView.findViewById(R.id.jadwal_anak);
            bb = itemView.findViewById(R.id.bb);
        }
    }
}