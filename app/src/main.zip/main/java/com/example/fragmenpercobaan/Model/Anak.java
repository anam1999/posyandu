package com.example.fragmenpercobaan.Model;

public class Anak {

    String id, name, usia,jadwal,bb;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsia() {
        return usia;
    }

    public void setUsia(String usia) {
        this.usia = usia;
    }
    public String getJadwal() {
        return jadwal;
    }
    public void setJadwal(String jadwal) {
        this.jadwal = jadwal;
    }
    public String getBb() {
        return bb;
    }
    public void setBb(String bb) {
        this.bb = bb;
    }
}