package com.example.fragmenpercobaan.Fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

public class PaketFragment extends Fragment {

    public PaketFragment() {
        // Required empty public constructor

    }
}
